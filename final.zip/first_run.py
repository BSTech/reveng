import subprocess, sys, os

def main():
    try:
        import importlib
        
        libs = ['shutil', 'sys' ,'os', 'zipfile', 'json', 'logging', 'struct', 'zlib', 'json']
        to_install = []
        
        for lib in libs:
            try:
                importlib.import_module(lib)
            except ImportError:
                print(f'Module {lib} is not found.')
                to_install.append(lib)
        
        if len(to_install) > 0:
            print('Do you want to install missing modules? They will be installed automatically.')
            print('Y/N: ')
            choice = input()
            if choice == 'Y' or choice == 'y':
                try:
                    subprocess.run([sys.executable, "-m", "pip", "install", *to_install], check=True)
                    print('All required modules are installed. Tools are almost ready to use.')
                except subprocess.CalledProcessError as e:
                    print('Cannot install the modules. Terminating preparation.')
                    return
        else:
            print('All required modules are already installed. Tools are almost ready to use.')
        
        print('Creating necessary folders...')
        
        dirs = ['./output', './output/images', './books', './idl']
        for dir in dirs:
            if not os.path.exists(dir):
                os.mkdir(dir)
        
        print('Checking necessary files...')
        
        files = ['./books_data.bin', './books_data_info.bin', './tessdata/heb.traineddata', './tessdata/pdf.ttf', './tessdata/scripts/Hebrew.traineddata', './libjpeg.dll', './libdjvulibre.dll']
        for file in files:
            if not os.path.exists(file):
                print(f'Could not find the file "{file[2:]}". Terminating preparation.')
                return
        
        print('Setup is finished. Everything seems to be ready.')
        
    except ModuleNotFoundError:
        print('Module "importlib" is not found. Terminating preparation.')


if __name__ == '__main__':
    main()
    print('Press ENTER to exit setup...')
    input()