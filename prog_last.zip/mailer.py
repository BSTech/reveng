import os, sys, smtplib
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import COMMASPACE, formatdate
from email import encoders

class Mailer:
    def __init__(self):
        self.smtpsrv = None
        self.user = None
        self.pw = None
        self.sbj = None
        self.to = []
        self.ssl = False
        
        with open('mailconf.txt', 'r', encoding='utf-8-sig') as f:
            for line in f:
                if not line: continue
                if line[0] == '#': continue
                i_cmt = line.find('#')
                if i_cmt >= 0: line = line[0:i_cmt]
                if not '=' in line: continue
                [key, value] = line.split('=', 1)
                key = key.strip().lower()
                value = value.strip()
                
                if key == 'server': self.smtpsrv = value
                elif key == 'user': self.user = value
                elif key == 'password': self.pw = value
                elif key == 'subject': self.sbj = value
                elif key == 'to': self.to.append(value)
                elif key == 'use_ssl':
                    self.ssl = value[0].lower() == 'y' if value else False
    
    def export_cfg(self):
        return self.smtpsrv, self.user, self.pw, self.sbj, self.to, self.ssl
    
    def send_mail(self, _content:str, _files:list = None):
        
        if not self.smtpsrv or not self.user or not self.pw or not len(self.to) or not self.sbj: return
        
        srv = self.smtpsrv
        port = None
        if ':' in self.smtpsrv:
            [srv, port] = self.smtpsrv.split(':', 1)
        
        try:
            port = int(port)
        except: pass
        finally:
            if not port: port = smtplib.SMTP_SSL_PORT if self.ssl else smtplib.SMTP_PORT
        
        msg = MIMEMultipart()
        msg['From'] = self.user
        msg['To'] = COMMASPACE.join(self.to)
        msg['Subject'] = self.sbj
        msg['Date'] = formatdate(localtime=True)
        
        msg.attach(MIMEText(_content))
        
        for file in _files or []:
            if not os.path.exists(file): continue
            
            p = MIMEBase('text', 'plain')
            with open(file, 'r') as f: p.set_payload(f.read())
            encoders.encode_base64(p)
            p.add_header('Content-Disposition', f'attachment; filename={os.path.basename(file)}')
            msg.attach(p)
            
        
        if self.ssl:
            with smtplib.SMTP_SSL(srv, port) as sssl:
                sssl.login(self.user, self.pw)
                sssl.sendmail(self.user, self.to, msg.as_string())
        else:
            with smtplib.SMTP(srv, port) as ssl:
                ssl.login(self.user, self.pw)
                ssl.sendmail(self.user, self.to, msg.as_string())
    
def main():
    if len(sys.argv) < 2:
        print('Usage: mailer.py test')
        print('       mailer.py send <content> <files...>')
        return
    
    args = sys.argv[1:]
    cmd = args[0].lower()
    
    if not cmd in ['test', 'send']:
        print(f'Invalid command {cmd}')
        return
    
    m = Mailer()
    
    if cmd == 'test':
        srv, user, pw, sbj, to, ssl = m.export_cfg()
        print(f'Server: {srv}\nUser: {user}\nPassword: {pw}\nSubject: {sbj}\nTo ({len(to)}): {", ".join(to)}\nUse SSL: {"Yes" if ssl else "No"}\n\n')
        
        m.send_mail('[TEST] An error-related information will be added here. Additionally a log file will be added as an attachment.')
        
        print('A test message has been sent!')
        return
    
    if cmd == 'send':
        if len(args) < 2:
            print('Missing argument: <content>')
            return
        
        flist = None
        if len(args) > 2: flist = args[2:]
        
        m.send_mail(args[1], flist)

if __name__ == '__main__': main()