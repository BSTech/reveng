"""
read_cstr - Reads a NULL-terminated (0 byte terminated) C-style ANSI string
"""
def read_cstr(raw, pos:int):
    l = 0
    while True:
        if raw[pos + l] == 0: break
        l += 1
        
    str = raw[pos : pos + l].decode()
    return (str, pos + l + 1)

"""
decrypt - Decrypts given data using specific keys

Decryption Routine:

    assume k's are 32-bit integers (4 bytes):
    kN = [k0, k1]
    kX = k2
    k[n] == nth byte of k (zero based), from left to right

    while there are more bytes:
        decrypted_byte = encrypted_byte XOR kX[2]
        buffer = decrypted byte
        kX = k1 + (k0 * (decrypted_byte + kX[3]) as unsigned 8-bit integer)
        go next byte
"""
def decrypt(data:bytes, key:list[int]):
    size = len(data)
    key_tmp = key
    key_xor = key[2]
    out = bytearray(size)
    cur = 0
    i = 0
    
    while i < size:
        byte_new = data[i] ^ ((key_xor >> 8) & 255)
        out[i] = byte_new
        i += 1
        cur = key_tmp[1] + key_tmp[0] * ((byte_new + key_xor) & 255)
        key_xor = cur
    
    return out

