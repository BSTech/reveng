from subprocess import Popen
from mailer import Mailer
import sys, random

def main():
    if len(sys.argv) == 1:
        print('Usage: startdm.py <app> [app = extractor | ocr]')
        return
    
    what = sys.argv[1].lower()
    token = random.randint(0, 100)
    logs = None
    
    if what == 'extractor':
        p = Popen(f'python3 program.py {token}')
        logs = ['log.log']
    elif what == 'ocr':
        p = Popen(f'ocrutil.exe {token}')
        logs = ['ocr.log', 'ocr_stdout.log', 'ocr_stderr.log']
    
    # wait for program to execute and finish
    p.communicate()
    
    if p.returncode != token:
        # program didn't exit with our token number (it is crashed), send mail now
        m = Mailer()
        m.send_mail(f'{what.capitalize()} has stopped unexpectedly.', logs)

if __name__ == '__main__': main()