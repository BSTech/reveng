import struct, zlib, json

"""
    'books_data_info.bin' is a table made of 700000 12-byte rows
    each row is made of 3 integers: offset, unknown (zero) and size [3 x 4 = 12 bytes]
    (note: not all rows are set, a big portion is empty, there are only 120066 rows)

    'books_data.bin' is a stream of book information made of compressed sections
    each section is a compressed JSON object
    
    book's JSON object: It is made of 4 parts:
    [0] = general book info
    [1] = pages info
    [2] = cross-references between books and within the book itself
    [3] = same as [2] but for words
"""

class BooksData:

    def __init__(self, bdat:str='Y:/Otzar 19/data/books_data.bin', bdatinfo:str='Y:/Otzar 19/data/books_data_info.bin'):
        if not bdat or not bdatinfo: raise Exception('Not all file paths are given')
        
        with open(bdatinfo, 'rb') as f:
            self.map_table = list(struct.iter_unpack('<III', f.read()))
            self.map_table_size = len(self.map_table)
        
        self.booksdata = open(bdat, 'rb')
        self.is_open = self.booksdata != None
        return
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
    
    def __getitem__(self, index):
        # update: return False or None instead of throwing an exception
        
        if index >= self.map_table_size: return False #raise Exception(f'Unexpected index {index}')
        offset, _, size = self.map_table[index]
        
        if not size: return None #raise Exception(f'Unexpected index {index} (empty or nonexistent book index has given)')
        
        self.booksdata.seek(offset, 0)
        data = self.booksdata.read(size)
        data = zlib.decompress(data)
        return json.loads(data)
    
    def close(self):
        if self.is_open:
            self.booksdata.close()
            self.is_open = not self.booksdata.closed
    
    def count(self): return self.map_table_size


#test
"""
with BooksData() as bd:
    b2 = bd[2] # book #2
    ...
    pass
#"""