import sys ,os, zipfile, json, logging
from decryptor import decrypt, read_cstr
from books_data import BooksData
from djvugen import djvu_generate, djvugen_readcfg

keys_book = [ 0xdd, 0xe1205, 0x8dc5 ] # for book header length information
keys_book2 = [ 0x5b7d, 0x2659, 0xdbe5 ] # for actual book content
keys_ide = [ 2921, 1317, 41693 ] # for *.ide files
keys_prn = [ 34534, 234462, 56434 ] # for printer (image) files (?)

# setup error handlers

logging.basicConfig(filename='log.log', level=logging.DEBUG)
logger = logging.getLogger(__name__)
logger.addHandler(logging.StreamHandler(stream=sys.stdout))

def uncaught_error_handler(ety, ev, etr):
    if issubclass(ety, KeyboardInterrupt):
        sys.__excepthook__(ety, ev, etr)
        return
    logger.critical('Uncaught exception', exc_info=(ety, ev, etr))

sys.excepthook = uncaught_error_handler

"""
prepare_ide - Creates the decrypted copy of the specified .ide file

.ide File Format

    Book ID (4 bytes) + Contents

    Original contents are encoded with code page 1255 (English + Hebrew)
    and we encode it back with UTF-8 so any text editor can read it
"""
def prepare_ide(path:str):
    # read ide file
    with open(path, 'rb') as f: data = f.read()

    # decrypt all and extract book id (not used)
    data = decrypt(data, keys_ide)
    bookId = int.from_bytes(data, 'little')

    # decrypt rest of file (all text), reverse all lines except the numbers and join them together
    # filtering on text can be done right before joining them
    data = data[4:].decode("cp1255").splitlines()
    #if reversed: lines = [line if line[0] in "1234567890" else line[::-1] for line in data]
    #else: lines = data
    ide_out = ' '.join(data)
    
    #if generate_file:
    #    with open(path + '.txt', 'w', encoding='utf-8-sig') as f: f.write(ide_out)
    
    return data


"""
prepare_book - Extracts pages from an encrypted .book file and puts them in a ZIP file

.book File Format

    BKF + Header Length (4 bytes) + Header + Data

    Header: Header Size (total of entries, 4 bytes) + 2 Unknown Integers (2x4 = 8 bytes) + Book ID (4 bytes) + Entries (referred as "table of contents")
    
    Entry: NULL-Terminated Page Name (variable size) + relative file offset of data (4 bytes) + data size (4 bytes)

    Header Length is encrypted with key #1 and the first 200 bytes of pages are encrypted with key #2, the rest is not encrypted.
"""
def prepare_book(path:str, zf:zipfile.ZipFile):
    with open(path, 'rb') as f: data = f.read()
    
    # Check if the file starts with "BKF"
    if data[0:3] != b'BKF': raise Exception(f'Invalid book file: {path}')
    
    # Get header length
    header_length = decrypt(data[3:7], keys_book)
    header_length = int.from_bytes(header_length, 'little')
    
    # Parse header
    header = decrypt(data[7:header_length + 7], keys_book2)
    
    size = int.from_bytes(header[0:4], 'little')
    unk1 = int.from_bytes(header[4:8], 'little')
    unk2 = int.from_bytes(header[8:10], 'little')
    bookId = int.from_bytes(header[10:14], 'little')
    
    # Extract "table of contents" next
    toc = []
    i = 14
    while i < size + 14:
        page_name, i = read_cstr(header, i)
        offset = int.from_bytes(header[i : i + 4], 'little')
        length = int.from_bytes(header[i + 4 : i + 8], 'little')
        toc.append((page_name, offset, length))
        i += 8
    
    # Create a zip file of book pages
    # File names are the same as page names
    # File extensions are decided by checking the bytes at file start with known signatures
    pos = size + 21
    page_counter = 1
    
    d_gen = djvugen_readcfg()
    
    for pname, offset, length in toc:
        
        # decrypt first 200 bytes and append the non-encrypted rest
        # if there is not enough bytes, decrypt all bytes we have got
        if length > 200: content = decrypt(data[pos + offset : pos + offset + 200], keys_book2) + data[pos + offset + 200 : pos + offset + length]
        else: content = decrypt(data[pos + offset : pos + offset + length], keys_book2)

        ext = 'bin' # fall back to .bin extension if the page format is none of those ones below
        if content[0:4] == b'AT&T': ext = 'djvu'
        elif content[0:4] == b'\x89PNG': ext = 'png'
        elif content[0:4] == b'\xff\xd8\xff\xe0': ext = 'jpg'
        elif content[0:4] == b'%PDF': ext = 'pdf'
        elif content[0:2] == b'BM': ext = 'bmp'
        elif content[0:4] == b'RIFF' and content[8:12] == b'WEBP': ext = 'webp' # found in book 29
        
        # append current page
        # since a .bin file is about an unknown format, we turn off the converter if it is enabled
        if ext == 'bin' or not d_gen:
            zf.writestr(f'[{page_counter}] {pname}.{ext}', content, zipfile.ZIP_DEFLATED, 6)
        else:
            zf.writestr(f'[{page_counter}] {pname}.djvu', djvu_generate(bytes(content)), zipfile.ZIP_DEFLATED, 6)
        
        page_counter += 1
        #with open(f'{path}_{pname}.{ext}', 'wb') as f: f.write(content)
    
    # For metadata:
    # zf.writestr('info.txt', 'test', zipfile.ZIP_DEFLATED, 3)
    
    return

def main(args):

    a_testmode = args[0] == '--test'
    
    # make an output directory (folder) if it does not exist
    # we will use this folder to store the decrypted books
    if not os.path.exists('./output'):
        os.mkdir('./output')
    
    if not os.path.exists('./output/images'):
        os.mkdir('./output/images')
    
    with zipfile.ZipFile('./output/texts.zip', 'a', zipfile.ZIP_DEFLATED, False, 6) as textszip, \
         zipfile.ZipFile('./output/full.zip', 'a', zipfile.ZIP_DEFLATED, False, 6) as fullzip, \
         open('./last_state.txt', 'w+') as state_file, BooksData() as bd:
        count = bd.count()
        skip_beginning = 0
        
        # read the last state if it exists
        # if the state is 'P'rocessing, continue from that place
        # if the state is 'F'inished, continue from the next one
        
        st = state_file.read()
        if len(st):
            [last, s] = st.split(' ')
            if s == 'P': skip_beginning = last
            elif s == 'F': skip_beginning = last + 1
        
        for bookId in range(skip_beginning, count):
            info = bd[bookId]
            if not info: continue
            info_first = info[0][0]
            
            print(f'Parsing book #{bookId} ... ', end='')
            
            # check if IDE file exists
            if not os.path.exists(f'Y:/Otzar 19/idl/{bookId}.ide') and not os.path.exists(f'Y:/Otzar 19/books/{bookId}.book'):
                print('not found, skipping')
                continue
            
            # save the state
            state_file.seek(0, 0)
            state_file.write(f'{bookId} P')
            state_file.flush()
            
            # create a zip file for each book
            with zipfile.ZipFile(f'./output/images/[{bookId}] {info_first["name"]}.zip', 'w', zipfile.ZIP_DEFLATED, False, 6) as imagezip:
                prepare_book(f'Y:/Otzar 19/books/{bookId}.book', imagezip)
            
            idl = prepare_ide(f'Y:/Otzar 19/idl/{bookId}.ide')
            
            # for page information, see books_data.py
            page_counter = 1
            for page in info[1]:
                pageData = page['pagedata'][0]
                pageName = page['name']
                if pageData['letter']: pageName = pageData['letter'] + f' ({pageName})'
                pageWordOffset = pageData['firstWord']
                pageWordsNum = pageData['numWords']
                pageName = f'[{page_counter}] {pageName}'
                # read the words on the page by indicated range [start : end]
                # last page is always recorded as it has zero words, so we need to check it
                if not pageWordsNum and page['position'] == len(info[1]):
                    pageWordsNum = len(idl) - pageWordOffset
                words = idl[pageWordOffset : pageWordOffset + pageWordsNum]
                
                # exclude empty pages
                if words: textszip.writestr(f'{bookId}-{info_first["name"]}/{pageName}.txt', ' '.join(words), zipfile.ZIP_DEFLATED, 6)
                page_counter += 1
                
                # prepare metadata
                """ meta = f"Name: {info_first['name']}\r\n"
                if info_first['volume']: meta += f"Volume: {info_first['volume']}\r\n"
                if len(info_first['authors']): meta += f"Author(s): {', '.join([author['name'] for author in info_first['authors']])}\r\n"
                if len(info_first['addnames']): meta += f"Add name(s): {', '.join([name['name'] for name in info_first['addnames']])}\r\n"
                if len(info_first['places']): meta += f"Place(s): {', '.join([place['name'] for place in info_first['places']])}\r\n"
                meta += f"Years: {info_first['fromyear'][0]['name'] if len(info_first['fromyear']) else ''}-{info_first['toyear'][0]['name'] if len(info_first['toyear']) else ''}\r\n"
                 """
                # add the metadata and backups of full text and information
                #textszip.writestr(f'{info_first["name"]}/__metadata.txt', meta)
            
            textszip.writestr(f'{bookId}-{info_first["name"]}/info.json', json.dumps(info))
            
            # naming style:
            # book name (volume*, authors*, from year*-to year*)
            # *: if the value doesn't exist, it will be omitted
            full_name = []
            info_years = ['', '']
            
            if info_first['volume']: full_name.append(info_first['volume'])
            if info_first['authors']: full_name.append(', '.join([author['name'] for author in info_first['authors']]))
            
            if 'fromyear' in info_first and len(info_first['fromyear']): info_years[0] = info_first['fromyear'][0]['name']
            if 'toyear' in info_first and len(info_first['toyear']): info_years[1] = info_first['toyear'][0]['name']
            if len(info_years[0]) or len(info_years[1]): full_name.append('-'.join(info_years))
            
            if len(full_name): full_name = f' ({", ".join(full_name)})'
            
            fullzip.writestr(f'{bookId}-{info_first["name"]}{full_name}.txt', ' '.join(idl))
            
            print('done')
            state_file.seek(0, 0)
            state_file.write(f'{bookId} F')
            state_file.flush()
    
    os.remove('./last_state.txt')
    return

try:
    if __name__ == '__main__': main(sys.argv)
except Exception as ex: logger.exception(ex)
#prepare_ide("C:\\Users\\User_Pc\\Desktop\\re\\ws6\\2.ide")
#prepare_book("C:\\Users\\User_Pc\\Desktop\\re\\ws6\\3.book")

# notes:
# ide A = non-reversed (correct)
# ide B = reversed
# https://home.mycloud.com/public/4965ea42-c8ff-43a7-85a3-066915bc7029/folders/ghp2pvkaj5zpzp4vx4cxdk62?single=true