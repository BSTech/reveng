from io import BytesIO
from PIL import Image
import struct

# configure generator operation:
# 'b' = DJVU will have the image in background plane
# 'f' = DJVU will have the image in foreground plane
# '' or different value = No DJVU file will be generated (passthrough)
DJVUGEN:str = ''

def djvugen_readcfg():
    global DJVUGEN
    if not DJVUGEN: return False
    DJVUGEN = DJVUGEN.upper()
    if not DJVUGEN in 'BF': return False
    return DJVUGEN[0]

# Crude DJVU converter function
# returns complete DJVU file in memory
# img_mem can be in any format PIL supports (including a file path)
def djvu_generate(img_mem:bytes) -> bytes:
    d_plane = djvugen_readcfg()
    if not d_plane: return img_mem
    
    # no need to create a cascaded file
    if img_mem[0:4] == b'AT&T': return img_mem
    
    img = Image.open(BytesIO(img_mem))
    img.load()
    
    with BytesIO() as jpg:
        dpi = 300
        img.save(jpg, format='jpeg', dpi=(dpi, dpi))
        jpg = jpg.getvalue()
        
        w = img.width
        h = img.height
        
        with BytesIO() as djvu:
            djvu.write(b'AT&TFORMxxxxDJVUINFO') # xxxx placeholder = final file size - header size (12)
            djvu.write(struct.pack('>IHH', 10, w, h))
            djvu.write(struct.pack('<HHBB', 24, dpi, 22, 1)) # 24 = version, 22 = gamma (2.2), 1 = no rotation
            djvu.write(f'{d_plane}Gjp'.encode()) # jpeg encoded chunk (foreground is invisible?)
            djvu.write(struct.pack('>I', len(jpg)))
            djvu.write(jpg)
            
            # store file size temporarily
            s = djvu.tell() - 12
            djvu.seek(8, 0) # go back to our placeholder xxxx
            djvu.write(struct.pack('>I', s)) # and write total size
            
            # get a bytes object
            output = djvu.getvalue()
    return output

# BROKEN, DO NOT USE
class DjVuMerger:
    def __init__(self):
        self.pages = []
        
    def add(self, djvu:bytearray):
        self.pages.append(djvu[4:])
        
    def merge(self) -> bytes:
        with BytesIO() as doc:
            pct = len(self.pages)
            doc.write(b'AT&TFORMxxxxDJVMDIRM')
            dir_size = 8 * pct
            doc.write(struct.pack('>IBH', dir_size + 3, 129, pct))
            
            dpos = doc.tell()
            doc.write(b'\x00' * dir_size)
            
            dirmp = []
            dirms = []
            
            for page in self.pages:
                dirmp.append(doc.tell())
                dirms.append(len(page))
                doc.write(page)
            
            doc.seek(dpos, 0)
            
            for offset in dirmp:
                doc.write(struct.pack('>I', offset))
            
            for size in dirms:
                doc.write(struct.pack('>I', size)[1:])
            
            doc.write(b'\x01' * pct)
            
            doc.seek(0, 2)
            l = doc.tell() - 12
            
            doc.seek(8, 0)
            doc.write(struct.pack('>I', l))
            
            output = doc.getvalue()
        self.pages.clear()
        return output
            
        
# testing

# DJVUGEN = ''
# with open('test.webp', 'rb') as img, open('testjpg.djvu', 'wb') as f: f.write(djvu_generate(img.read()))
# OK

"""
with open('test_m.djvu', 'wb') as out:
    lst = ['a', 'b', 'c']
    dm = DjVuMerger()
    
    for fn in lst:
        with open(f'{fn}.djvu', 'rb') as f:
            dm.add(f.read())
    
    out.write(dm.merge())

FAIL
"""